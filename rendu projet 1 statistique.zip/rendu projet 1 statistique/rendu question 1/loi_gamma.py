import numpy as np
from matplotlib import pyplot as plt

np.random.gamma
plt.hist(np.random.gamma(1,1,10000), alpha=.5)
plt.show()

